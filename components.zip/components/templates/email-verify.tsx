import * as React from 'react';
import { Html, Button } from "@react-email/components";

export function VerifyEmail() {
  return (
    <Html lang="en">
      <Button>Click me</Button>
    </Html>
  );
}
